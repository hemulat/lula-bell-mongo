var ourRequest=new XMLHttpRequest();
//ourRequest.open('GET', "")
// ourRequest.onload=function() {
//   var ourData=ourRequest.responseText();
// };
var item_info= $('#all_items').data('temp')
console.log(item_info);
//ourRequest.send();
